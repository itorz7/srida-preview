เอกสารแบรนด์
- srida-brand-guideline.pdf: คู่มือแบรนด์ (โลโก้ สี ฟอนต์ มาสคอต และแนวทางการใช้งาน)
- boilerplate/: ข้อความแนะนำบริษัท สั้นและยาว ทั้งภาษาไทยและอังกฤษ สำหรับใช้ในข่าวประชาสัมพันธ์ โปรไฟล์บริษัท และเอกสารทางการ
- name-guide-th/en.txt: วิธีสะกดและออกเสียงชื่อ
ข้อความเขียนจากข้อมูลที่ยืนยันแล้วเท่านั้น (แท็กไลน์ ที่มาชื่อ สินค้า 5 สาย) ยังไม่มีปีก่อตั้ง ตัวเลข ลูกค้า หรือที่อยู่ หากมีข้อมูลจริงเพิ่มเติม กรุณาระบุให้ครบถ้วนก่อนนำไปเผยแพร่

Guideline PDF, boilerplates and name guide. Text uses confirmed facts only (tagline, name origin, five products); no founding year, numbers, clients or address; add real ones before publishing.
