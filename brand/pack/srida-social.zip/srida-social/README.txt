ภาพโซเชียล (สร้างจากภาพบักสีดา 3D จริง + โลโก้ + พื้นสีเรียบ ไม่มีลายหรือภาพวาด)
- profile-*-1024.png: ภาพโปรไฟล์ สี่เหลี่ยมจัตุรัส ตัวภาพอยู่ในวงกลมปลอดภัย 80% (Facebook, LINE, YouTube, X ครอปเป็นวงกลมได้)
- fb-cover-1640x624-v3.png: ปก Facebook ไม่มีลาย เนื้อหาอยู่ใน x 390–1239 ข้อความอยู่เหนือ y 280 เว้นโซนวงกลมโปรไฟล์กลางล่าง (ตัวเลขปลอดภัยมือถือจาก kit/build_kit.py ของ super1)
- line-oa-cover-1080x878.png: LINE OA
- youtube-banner-2560x1440.png: เนื้อหาทั้งหมดอยู่ใน safe area 1546x423 กลางภาพ (เห็นได้ทุกอุปกรณ์)
- x-header-1500x500.png: X (Twitter) · og-image-1200x630.png: ภาพแชร์ลิงก์ (Open Graph)
สามารถนำไปอัปโหลดตามขนาดที่ระบุไว้ได้ทันที โดยไม่ต้องย่อหรือขยาย

Profile images and covers sized for Facebook (1640x624, v3: phone-safe, no pattern), LINE OA (1080x878), YouTube (2560x1440, content inside 1546x423 safe area), X (1500x500) and OG (1200x630). Real 3D mascot + logo + flat colour only.
