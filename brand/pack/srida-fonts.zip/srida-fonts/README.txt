ฟอนต์แบรนด์
- Outfit (ตัวอักษรละติน): Outfit-Variable.ttf ปรับน้ำหนักได้ 100–900 · wordmark ใช้น้ำหนัก 750
- Prompt (ภาษาไทย): Regular / Medium / SemiBold / Bold
ทั้งสองฟอนต์ได้รับอนุญาตภายใต้ SIL Open Font License 1.1 สามารถใช้งานในเชิงพาณิชย์ได้ฟรี ฝังในเว็บ/แอป/เอกสารได้ ห้ามจำหน่ายไฟล์ฟอนต์เดี่ยว ๆ · ดูข้อความสัญญาอนุญาตฉบับเต็มได้ในโฟลเดอร์ licence/
ข้อความทั่วไปใช้ Outfit + Prompt · เอกสารทางการใช้ Prompt

Outfit (Latin) and Prompt (Thai), both SIL OFL 1.1: free for commercial use and embedding; do not sell the fonts on their own. Full licence texts in licence/.
