Wordmark srida.ai — โลโก้หลัก
- color: บนพื้นขาวหรือสีอ่อน · on-dark: บนพื้นเข้ม · black: ดำล้วน · white: ขาวล้วนบนพื้นเข้ม
กว้างไม่ต่ำกว่า 96 px ถ้าเล็กกว่านั้นให้ใช้ไอคอน · เว้นที่ว่างรอบโลโก้อย่างน้อยเท่าความสูงของตัว s
ไฟล์ -white และ -on-dark ใน PDF มีพื้นหมึก (#0B0B0C) รองไว้ เพราะ PDF ไม่มีพื้นโปร่งใสให้เห็นตัวอักษรขาว · PNG ทุกไฟล์พื้นโปร่งใส · SVG ตัวอักษรเป็นเส้น (outline) เปิดได้โดยไม่ต้องมีฟอนต์

Wordmark: color (on white), on-dark, black, white. Minimum width 96 px; below that use the mark.
PDFs of -white and -on-dark carry an ink (#0B0B0C) backing plate (PDF has no transparent page). PNGs are transparent. SVG text is outlined (no fonts needed).
