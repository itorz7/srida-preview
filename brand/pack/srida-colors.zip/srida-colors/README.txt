สีแบรนด์ Srida.ai
สี | HEX | RGB | HSL | OKLCH | CMYK (ประมาณ)
ชมพูเนื้อ (pink) | #F0647E | 240, 100, 126 | 349°, 82%, 67% | 0.685 0.173 11.5 | 0/58/48/6
เขียวใบ (leaf) | #3A9A40 | 58, 154, 64 | 124°, 45%, 42% | 0.609 0.156 144.4 | 62/0/58/40
หมึก (ink) | #0B0B0C | 11, 11, 12 | 240°, 4%, 5% | 0.15 0.002 286.1 | 8/8/0/95
เทา (grey) | #9A9AA0 | 154, 154, 160 | 240°, 3%, 62% | 0.688 0.009 286.2 | 4/4/0/37
เขียวเปลือก (rind) | #8CC63F | 140, 198, 63 | 86°, 54%, 51% | 0.76 0.174 129.8 | 29/0/68/22
ครีมเมล็ด (seed) | #FFE9C7 | 255, 233, 199 | 36°, 100%, 89% | 0.943 0.05 78.7 | 0/9/22/0
ครีมพื้น (cream) | #FFF6E9 | 255, 246, 233 | 35°, 100%, 96% | 0.977 0.02 77.3 | 0/4/9/0
ขาว (white) | #FFFFFF | 255, 255, 255 | 0°, 0%, 100% | 1.0 0.0 0 | 0/0/0/0
ชมพูเข้ม (pink-text) | #C8355A | 200, 53, 90 | 345°, 58%, 50% | 0.561 0.183 10.9 | 0/74/55/22
เทาเข้ม (grey-text) | #6B6B72 | 107, 107, 114 | 240°, 3%, 43% | 0.53 0.011 286.0 | 6/6/0/55

ไฟล์: srida-colors.css (CSS variables) · srida-colors.json · tailwind.snippet.js · figma-tokens.json (รูปแบบ Design Tokens ใช้กับ Tokens Studio ได้) · srida-colors.ase (Adobe Swatch ใช้ได้ใน Photoshop/Illustrator/InDesign)
CMYK คือค่าแปลงโดยประมาณจาก RGB ก่อนพิมพ์จริงแนะนำให้พิมพ์ทดสอบเทียบสีกับโรงพิมพ์ · แบรนด์ไม่มีเบอร์สี Pantone

Colour tokens as CSS, JSON, Tailwind, Figma tokens and Adobe ASE. CMYK is an approximate conversion; proof with your printer. No Pantone numbers.
