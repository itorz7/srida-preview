// tailwind.config.js → theme.extend
module.exports = {
  theme: { extend: {
    colors: { srida: {
      pink: '#F0647E',
      leaf: '#3A9A40',
      ink: '#0B0B0C',
      grey: '#9A9AA0',
      rind: '#8CC63F',
      seed: '#FFE9C7',
      cream: '#FFF6E9',
      white: '#FFFFFF',
      pink-text: '#C8355A',
      grey-text: '#6B6B72',
    } },
    fontFamily: { sans: ['Outfit', 'Prompt', 'sans-serif'], thai: ['Prompt', 'sans-serif'] },
  } },
}
