ผลิตภัณฑ์ 5 สาย
Srida Khuet — คึด (คิด) · LLM · ท่าบักสีดา: llm
Srida Yin — ยิน (ได้ยิน) · ASR (ถอดเสียง) · ท่า: asr
Srida Wao — เว้า (พูด) · TTS (สร้างเสียง) · ท่า: tts
Srida Khua — ขัว (สะพาน) · MT (แปลภาษา) · ท่า: mt
Srida Berng — เบิ่ง (ดู) · Vision · ท่า: vision
โลโก้ผลิตภัณฑ์ใช้โครงเดียวกับ wordmark (Outfit) ชื่อสินค้าสีชมพู มีบรรทัดเล็กบอกคำอีสาน (คำไทยกลาง) และชนิดสินค้า · ในโฟลเดอร์ png/<สินค้า>/ มี mascot-<ท่า>-1024/2048.png ท่าประจำสินค้าด้วย
ไฟล์ -white และ -on-dark ใน PDF มีพื้นหมึก (#0B0B0C) รองไว้ เพราะ PDF ไม่มีพื้นโปร่งใสให้เห็นตัวอักษรขาว · PNG ทุกไฟล์พื้นโปร่งใส · SVG ตัวอักษรเป็นเส้น (outline) เปิดได้โดยไม่ต้องมีฟอนต์

Five products; lockups reuse the wordmark build (Outfit), product name in pink with a small line: Isan word (Central Thai meaning) · product type. png/<product>/ also holds the mascot pose PNG of each product.
PDFs of -white and -on-dark carry an ink (#0B0B0C) backing plate (PDF has no transparent page). PNGs are transparent. SVG text is outlined (no fonts needed).
