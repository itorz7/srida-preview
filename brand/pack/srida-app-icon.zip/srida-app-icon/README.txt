App icon & favicon
- favicon.ico (16/32/48) · favicon.svg (ไอคอนฝรั่งแบบเล็ก) · png/favicon-16/32/48
- png/apple-touch-icon-180.png (พื้นขาวเต็มสี่เหลี่ยม ระบบ iOS จะมนมุมให้อัตโนมัติ)
- png/icon-192, icon-512 (แผ่นขาวมนมุม) · png/icon-maskable-512.png (ไอคอนอยู่ในโซนปลอดภัย 80% ของวงกลม)
- png/app-icon-white-1024.png, app-icon-ink-1024.png: ส่งขึ้น App Store / Play Store
- site.webmanifest และ head-snippet.html เป็นตัวอย่าง: ปรับ path ให้ตรงกับเว็บ

Favicon set (ICO 16/32/48, SVG, PNG 16/32/180/192/512, maskable 512), example site.webmanifest and <head> snippet. Adjust paths to your site.
