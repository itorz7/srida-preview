บักสีดา — มาสคอต
"บักสีดา" คือฝรั่ง (ภาษาอีสาน) ผ่าซีก สวมชฎาทองของนางสีดา ภาพทุกท่าเป็นภาพ 3D จริง ตัดพื้นหลังแล้ว
ท่า: front = ด้านหน้า (ท่ายืนหลัก) · three-quarter = มุม 3/4 (ท่ายืนหลัก) · back = ด้านหลัง · wave = โบกมือทักทาย · llm = คิดและคุย (Srida Khuet · LLM) · asr = ฟัง (Srida Yin · ASR) · tts = พูด (Srida Wao · TTS) · mt = แปลภาษา (Srida Khua · MT) · vision = มองภาพ (Srida Berng · Vision)
ไฟล์ 2048 ได้จากภาพต้นฉบับ 4096 ย่อลง ไม่ได้ขยายจากไฟล์เล็ก · ตัวละครอยู่กลางภาพ เว้นขอบโปร่งใสโดยรอบ

กติกา
- ใช้ไฟล์ตามที่จัดเตรียมไว้ ไม่วาดใหม่ ไม่ยืดหรือบีบ ไม่กลับซ้ายขวา ไม่เปลี่ยนสี และไม่ถอดชฎาหรือใบ
- วางบนพื้นเรียบ (ขาว ครีม ชมพูอ่อน หมึก) ไม่วางบนลายหรือภาพรก
- ท่าประจำสินค้าใช้คู่กับสินค้านั้น: llm=Khuet · asr=Yin · tts=Wao · mt=Khua · vision=Berng
- เอกสารทางการใช้โลโก้ ไม่ใช้มาสคอตแทนโลโก้

Nine transparent PNG poses at 1024 and 2048 (2048 is downscaled from the 4096 originals, never upscaled). Use as supplied: no redrawing, stretching, flipping or recolouring; place on plain backgrounds; the mascot never replaces the logo on formal documents.
